#!/bin/bash


# Assumption - tar file has been unpacked
#
# two files unpacked  - zds-usr.tar and zds-etc-tar
#
# Process is to unpack these files to /etc and /usr respectively
#
# then restart all processes


# Unpack etc file to /etc

sudo tar xvf zds-usr.tar -C /

# Unpack usr file to /usr

sudo tar xvf zds-etc.tar -C /

# Restart the Management Console

sudo zds-ui restart

# Restart ZeroDown Software

sudo zerodown restart


